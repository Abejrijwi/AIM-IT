  <div class="layout-footer">
        <div class="layout-footer-body">
          <!--<small class="version"></small>-->
          <small class="copyright">2019 &copy; AIMIT - Asian Institute of Management & Information Technology<a href="#">  Admin Panel</a></small>
        </div>
      </div>
    </div>
    
    <script src="<?php echo base_url("public/admin/js/vendor.minf9e3.js?v=1.1");?>"></script>
    <script src="<?php echo base_url("public/admin/js/elephant.minf9e3.js?v=1.1");?>"></script>
    <script src="<?php echo base_url("public/admin/js/application.minf9e3.js?v=1.1");?>"></script>
    <script src="<?php echo base_url("public/admin/js/demo.minf9e3.js?v=1.1");?>"></script>
    
  </body>


</html>